from django import forms

class TransactionForm(forms.Form):

    amount = forms.FloatField(
        label='Amount',
        widget=forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'})
    )
    
    oldbalanceOrg = forms.FloatField(
        label='Old Balance Origin',
        widget=forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'})
    )
    
    newbalanceOrig = forms.FloatField(
        label='New Balance Origin',
        widget=forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'})
    )
    
    oldbalanceDest = forms.FloatField(
        label='Old Balance Destination',
        widget=forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'})
    )
    
    newbalanceDest = forms.FloatField(
        label='New Balance Destination',
        widget=forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'})
    )