from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from django.db.models import Sum, Count, Avg
from .models import AnalysisReport, TransactionItem
from .predictor import FraudPredictor
import pandas as pd
import csv

predictor = FraudPredictor()

def home(request):
    """Landing page for uploading files"""
    if request.method == 'POST' and request.FILES.get('file'):
        file = request.FILES['file']
        try:
            df = pd.read_csv(file)
            
            # Basic validation
            required_cols = ['step', 'type', 'amount', 'oldbalanceOrg', 'newbalanceOrig', 'oldbalanceDest', 'newbalanceDest']
            if not all(col in df.columns for col in required_cols):
                return render(request, 'dashboard/home.html', {'error': 'Invalid CSV columns'})

            # Predict
            probs, preds = predictor.predict(df)
            
            # Calculate Stats
            df['is_fraud'] = preds
            df['probability'] = probs
            
            fraud_rows = df[df['is_fraud'] == 1]
            
            # Save Report
            report = AnalysisReport.objects.create(
                filename=file.name,
                total_transactions=len(df),
                fraud_transactions=len(fraud_rows),
                amount_at_risk=fraud_rows['amount'].sum()
            )

            # Bulk Create Transactions (Optimized)
            # Limiting to 5000 rows for performance in this demo
            objs = [
                TransactionItem(
                    report=report,
                    step=row.step,
                    type=row.type,
                    amount=row.amount,
                    oldbalanceOrg=row.oldbalanceOrg,
                    newbalanceOrig=row.newbalanceOrig,
                    oldbalanceDest=row.oldbalanceDest,
                    newbalanceDest=row.newbalanceDest,
                    is_fraud_prediction=bool(row.is_fraud),
                    fraud_probability=float(row.probability)
                )
                for row in df.head(5000).itertuples()
            ]
            TransactionItem.objects.bulk_create(objs)

            return redirect('report_detail', report_id=report.id)

        except Exception as e:
            return render(request, 'dashboard/home.html', {'error': str(e)})

    return render(request, 'dashboard/home.html')

def report_detail(request, report_id):
    """Interactive results for a single upload"""
    report = get_object_or_404(AnalysisReport, id=report_id)
    # Optimization: Only fetch fields needed for table
    transactions = report.items.all().order_by('-fraud_probability')
    return render(request, 'dashboard/report_detail.html', {
        'report': report,
        'transactions': transactions
    })

def report_history(request):
    """List past uploads"""
    reports = AnalysisReport.objects.order_by('-upload_date')
    return render(request, 'dashboard/history.html', {'reports': reports})

def analytics_dashboard(request):
    """Global trends dashboard"""
    total_reports = AnalysisReport.objects.count()
    if total_reports == 0:
        return render(request, 'dashboard/analytics.html', {'no_data': True})

    # Global Stats
    total_scanned = AnalysisReport.objects.aggregate(Sum('total_transactions'))['total_transactions__sum']
    total_fraud = AnalysisReport.objects.aggregate(Sum('fraud_transactions'))['fraud_transactions__sum']
    total_risk = AnalysisReport.objects.aggregate(Sum('amount_at_risk'))['amount_at_risk__sum']

    # Data for Charts
    # 1. Fraud by Type
    type_stats = TransactionItem.objects.filter(is_fraud_prediction=True).values('type').annotate(count=Count('id'))
    
    # 2. High Risk vs Low Risk Fraud (Arbitrary threshold of $10,000)
    high_val_fraud = TransactionItem.objects.filter(is_fraud_prediction=True, amount__gte=10000).count()
    low_val_fraud = TransactionItem.objects.filter(is_fraud_prediction=True, amount__lt=10000).count()

    return render(request, 'dashboard/analytics.html', {
        'total_scanned': total_scanned,
        'total_fraud': total_fraud,
        'total_risk': total_risk,
        'type_labels': [x['type'] for x in type_stats],
        'type_data': [x['count'] for x in type_stats],
        'val_data': [high_val_fraud, low_val_fraud]
    })

def download_csv(request, report_id):
    report = get_object_or_404(AnalysisReport, id=report_id)
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="Report_{report.id}.csv"'
    
    writer = csv.writer(response)
    writer.writerow(['Step', 'Type', 'Amount', 'Prediction', 'Probability'])
    
    # Streaming large data
    items = report.items.all().iterator()
    for item in items:
        pred = "FRAUD" if item.is_fraud_prediction else "LEGITIMATE"
        writer.writerow([item.step, item.type, item.amount, pred, f"{item.fraud_probability:.4f}"])
        
    return response

def delete_report(request, report_id):
    if request.method == 'POST':
        report = get_object_or_404(AnalysisReport, id=report_id)
        report.delete()  
    return redirect('history')